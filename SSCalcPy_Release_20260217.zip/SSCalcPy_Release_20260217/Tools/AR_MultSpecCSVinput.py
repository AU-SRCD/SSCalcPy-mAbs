# -*- coding: utf-8 -*-
"""
Created on Januar 2025

@author: au513
"""

#*** ALISON : This is IMPORTANT for you: ***

#This is the csv file you use:
MyProteinFile = "Multiple peptide spectra.csv"

#Your CSV file should be in a subfolder of the Tools folder
MyProteinDir = "AR_MultSpecCSV/"

#New folder for Alison's own A and F files:
RefDataDir = "../CDRefDataAR/" #this is the relative path from the Tools dir
#USE The Alison's Versions: all named with AR
F_file = "AR-AU-F128_T-NoBeta-II-Feb26.txt" #"AR-AU-F128_T-Jan26.txt"
A_file = "AR-AU-A128-NoBeta-II-178nm-Feb26.txt" #"AR-AU-A128_PCDDB-Jan26.txt"
#As the label file is passed to SelconPy, use the full relative path to the file
lbl_file = RefDataDir+"Labels-AR-AU-A128-NoBeta-II-Feb26.txt"

delimIs = ',' #Alison's data are comma separated

#END: *** ALISON : THis is important for you ***:
    


#Before running this code directly in Spyder: enter "%matplotlib qt" into the Console (and press enter)
# Remember to run %matplotlib qt in Console

#Import 
import numpy as np
import sys
#Check that the file SelconsFunction.py is in the path given below
sys.path.append("../Selcon3Py")
from SelconsFunction import SelconsPy #SelconsFunction.py contains the SelconPy function
    
#General setting needed in SelconsPy
AU_or_BBK = 'AR' #Needed to show SelconsPy that this is Alison's data
CD_or_IR = 'CD' #Needed for SelconsPy to limit the A matrix to only data in the query proteins, i.e. where LimWL >= 175
ShouldIPlot = 1
ShouldIAlsoPlotSelcon2 = 0

#Find out of there are header lines in the protein data file
file1 = open(MyProteinDir + MyProteinFile, 'r')
Lines = file1.readlines()
file1.close()

skip = 0; readRows = 0
SkipChars = [";", "#", "X", " "] #List of first characters in line to be skipped
for line in Lines:
    if(line[0] in SkipChars or line[0].isnumeric() == False):
        if (readRows == 0):
            skip += 1
    else:
        readRows += 1
print('Skipping first', skip, 'rows of protein data file', MyProteinFile)
print('Number of rows to read: ', readRows) #Read max_rows rows of content after skiprows lines.

#Now load all the data in the csv file
q_load = np.loadtxt(MyProteinDir + MyProteinFile, dtype='f', delimiter=delimIs, skiprows=skip, max_rows=readRows)
print (f"q_load Shape {q_load.shape}")
#Give WL part and spectra part new names
WL = q_load[:,0]
spectra = q_load[:,1:]
print (f"spectra Shape {spectra.shape}")
#Exctrac the names of the spectra in the first row of the file
spectraNamesTmp = np.loadtxt(MyProteinDir + MyProteinFile, dtype='str', delimiter=delimIs, skiprows=0, max_rows=1)
spectraNames = spectraNamesTmp[1:]
print (f"spectraNames Shape {spectraNames.shape}")

#Get the A and F matrices
F_load =  np.loadtxt(RefDataDir + F_file, dtype='f', delimiter='\t') #SMP180
A_load = np.loadtxt(RefDataDir + A_file, dtype='f', delimiter='\t') #SMP180
#Labels are in RefDataDir + "Labels-AR-AU-A128-Jan26.txt"
F_AR = F_load[:,:71] #All SS structures. First 71 spectra (SP175)
A_AR = A_load[:63,:71] #First 63 WL (240-178 as it also contains mAb), first 71 spectra (SP175)
#Add Alpha R and D to Helix and Beta R and D to Sheet
Fhelix = F_AR[0,:] + F_AR[1,:] #AlphaR + AlphaD  print('Fhelix shape: ', Fhelix.shape)
Fsheet = F_AR[2,:] + F_AR[3,:] #BetaR + BetaD
F1 = np.array([Fhelix,Fsheet,F_AR[4,:],F_AR[5,:]])       #F1=np.concatenate((Fhelix, Fsheet, F[4,:], F[5,:]))
A1 = A_AR
print('F1 shape: ', F1.shape, '. A1 shape: ', A1.shape)

#Selcon3 limits
RefDataHighWL = 240
RefDataLowWL = 178 #175 #for AU ref data
DataSet = 'AR-SP178' #'AR-SP175'
#Label file to be used
dictPassedToSelconPy = {'lblFile' : lbl_file}

HighWL = max(WL)
if HighWL < RefDataHighWL:
    print(f'Error: The highest WL ({HighWL}) in data is the below the Reference data high WL ({RefDataHighWL})')
    sys.exit()


#The query protein must have data starting from start in A (240 nm) and downward
minWLFloat = np.min(WL)
LimWL = max(int(minWLFloat), RefDataLowWL) #minWL
print('LimWL is determined to be=',LimWL)
wl_increasing = np.linspace(LimWL, RefDataHighWL, int(1+(RefDataHighWL-LimWL))) #WL range LimWL, LimWL+1, ..., 238, 239, 240
  
#Loop over the spectra in the CSV file
print(f'Looping over spectra in CVS file using LimWL: {LimWL}')
for spectrumNo in range(spectra.shape[1]):
    #Interpolate the spectrum onto the wavelength range LimWL, LimWL+1, ..., 238, 239, 240
    q1=spectra[:,spectrumNo] #pure spectrum, No WL
    if (WL[-1] < WL[0]):
        q_interp = np.interp(wl_increasing, np.flip(WL), np.flip(q1))
    else:
        q_interp = np.interp(wl_increasing, WL, q1)
    #reverse q order to fit order of CD reference data
    q = np.flip(q_interp)
    
    print(f'spectraName{spectrumNo}: {spectraNames[spectrumNo]}.  q shape: {q.shape}')
    #Give the proteinfile a name for output, and call Selcon3
    MyProteinFile = "ProteinNo_{:d}".format(spectrumNo) + " - " + spectraNames[spectrumNo]+".txt"
    Selcon3ResultsList = SelconsPy(A1 ,F1, q, ShouldIPlot, ShouldIAlsoPlotSelcon2, LimWL, RefDataLowWL, MyProteinFile, MyProteinDir,AU_or_BBK, CD_or_IR, 'Tools', **dictPassedToSelconPy)
    
    #Output the results of the Selcon3
    SP_or_SMP = ''
    fOut = open(MyProteinDir + MyProteinFile[0:-4]+'_SELCON3-'+ SP_or_SMP + '' + DataSet + '_out.txt', 'w')
    for item in Selcon3ResultsList:
        fOut.write("%s\n" % item)
    fOut.close()
    
    #Output all the SS results into one file
    if (spectrumNo==0):
        with open(MyProteinDir + 'All_Results'+'_SELCON3-'+ DataSet + '_out.txt', 'w') as f:
            item0=Selcon3ResultsList[-3]
            f.write("%s\n" % item0)
    #END: if (RefProteinNo==0):
    with open(MyProteinDir + 'All_Results'+'_SELCON3-'+  DataSet + '_out.txt', 'a') as f:
        item1=Selcon3ResultsList[-2]
        f.write("%s\n" % item1)
    
    #Output all the Prot Used into one file
    if (spectrumNo==0):
        with open(MyProteinDir + 'All_Results'+'_SELCON3-'+ DataSet + 'ProtUsed_out.txt', 'w') as f:
            #f.write("%s\n" % MyProteinFile[0:-4])
            item0='' #Selcon3ResultsList[-3]
            f.write("%s\n" % item0)
    #END: if (RefProteinNo==0):
    with open(MyProteinDir + 'All_Results'+'_SELCON3-'+  DataSet + 'ProtUsed_out.txt', 'a') as f:
        f.write("%s\n" % MyProteinFile[0:-4])
        item1=Selcon3ResultsList[-1]
        f.write("%s\n" % item1)
#END: for spectrumNo in range(....