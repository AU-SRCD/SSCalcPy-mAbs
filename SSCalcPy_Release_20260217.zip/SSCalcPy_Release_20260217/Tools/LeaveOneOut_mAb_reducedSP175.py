# -*- coding: utf-8 -*-
"""
Created on Wed Sep 20 12:19:05 2023

@author: au513
"""

import numpy as np
import sys
#Check that the file SelconsFunction.py is in the path given below
sys.path.append("../Selcon3Py")
from SelconsFunction import SelconsPy #SelconsFunction.py contains the SelconPy function

#Remember to give the correct protein file name and path here:
#Path or directory
#MyProteinDir = "../Data/timW/"
#MyProteinDir = "../TestProteins/"
MyProteinDir = "IR_SpectraFromA/"
#MyProteinDir = "tmpMayBeDeleted/"
MyProteinDir = "CD-IR_SpectraFromA/"
MyProteinDir = "SpectraFromA/"
MyProteinDir = "SpectraFromA-mAb/"
MyProteinDir = "AnalysisOf_A-mAbs_pH3/"
MyProteinDir = "mAbsAnalysis_ReducedSP175Set/"
MyProteinDir = "SpectraFromA-mAb_Jan2026/"
MyProteinDir = "mAbsAnalysis_ReducedSP175Set_2/"
ReducedSP175LOOV = True
#ReducedSP175LOOV = False 


CD_or_IR = 'CD-IR2cm'
scaleIR = 15 #15.0
#CD_or_IR = 'IR'
#CD_or_IR = 'CD'
CD_or_IR = 'CDmAb'
NumSSforCDmAb = 4 #6

mAbs_pH3Loop = True 
mAbs_pH3Loop = False

AU_or_BBK = ''
LoopFromSpectrum = 0

ShouldIPlot = 1
ShouldIAlsoPlotSelcon2 = 0

if (CD_or_IR == 'CDmAb'):
    #RefDataDir = "CDRefDataAU/" #this is the relative path to the GUI .py file
    #RefDataDir_mAb = "CDRefData_mAb/" #this is the relative path to the GUI .py file
    RefDataDir = "../CDRefDataAU/" #this is the relative path from the Tools dir
    RefDataDir_mAb = "../CDRefData_mAb/" #this is the relative path from the Tools dir
    F1 =  np.loadtxt(RefDataDir + "AU-F128_T-Nov22.txt", dtype='f', delimiter='\t') #SMP180
    A1 = np.loadtxt(RefDataDir + "AU-A128_PCDDB-Nov22.txt", dtype='f', delimiter='\t') #SMP180
    F_SP = F1[:,:71] #All SS structures. First 63 WL (240-178), first 71 spectra (SP175)
    A_SP = A1[:63,:71]
    print('F_SP shape: ', F_SP.shape, '. A_SP shape: ', A_SP.shape)
    if ReducedSP175LOOV:
        #Fist 35 SP175 refs : 0-34
        # F_SP = F1[:,:35] #All SS structures. First 63 WL (240-178), first 71 spectra (SP175)
        # A_SP = A1[:63,:35]
        # #Last SP175 ref, but includeFist 35 SP175 refs : 0-34
        IgGProtNumber = 38
        # F1_SP = F1[:,:35] 
        # A1_SP = A1[:63,:35]
        for RefProteinNo in range(35, 71): #Either 0 to 34 range(0,35) OR 35 to 70 range(35,71)
            if RefProteinNo == IgGProtNumber:
                pass
            else:
                A_SP[:,RefProteinNo] = 0
            #F_SP[:,RefProteinNo] = 0
            #print('A col 0-3', A_SP[:, :4])
            # sys.exit()
        #Make sure the IgG is still in the set
        #A_SP[:,IgGProtNumber] = A1[:63,IgGProtNumber]
        print('Fist 10 rows of A col 30-40 \n', A_SP[:10, 30:41])
        #print('Fist 10 rows of A IgGProtNumber \n', A1[:,IgGProtNumber])
        #sys.exit()
        
    F1mAb =  np.loadtxt(RefDataDir_mAb + "F14-mAb178-T-Feb25.txt", dtype='f', delimiter='\t') 
    A1mAb = np.loadtxt(RefDataDir_mAb + "A14-mAb178-Feb25.txt", dtype='f', delimiter='\t')
    F_mAb = F1mAb[:,:]
    A_mAb = A1mAb[:,:]
    F=np.concatenate([F_SP,F_mAb], axis=1)
    A=np.concatenate([A_SP,A_mAb], axis=1)
    
    #Use A1 and F1 in LOOV
    A1=A
    F1=F
    #Should we reduce from SStruct = ['AlphaR','AlphaD', 'BetaR', 'BetaD', 'Turns', 'Other'] to SStruct = ['Helix','Sheet', 'Turns', 'Other']
    if (NumSSforCDmAb == 4):
        Fhelix = F[0,:] + F[1,:] #AlphaR + AlphaD  print('Fhelix shape: ', Fhelix.shape)
        Fsheet = F[2,:] + F[3,:] #BetaR + BetaD
        F1 = np.array([Fhelix,Fsheet,F[4,:],F[5,:]])       #F1=np.concatenate((Fhelix, Fsheet, F[4,:], F[5,:]))
    print('F1 shape: ', F1.shape, '. A1 shape: ', A1.shape)
    
    LoopFromSpectrum = A_SP.shape[1]
    print('Loop in LOOV from ', LoopFromSpectrum)
    
    LimWL = 178 #for CDmAb data
    RefDataHighWL = 240
    RefDataLowWL = 178 #for CDmAb data
    DataSet = 'SP-mAb178'
    
    #sys.exit()
    
    
#END: if (CD_or_IR == 'CDmAb'):

if (CD_or_IR == 'IR'):
    #Note on reference set: Reference publication
    #Marco Pinto Corujo, Adewale Olamoyesan, Anastasiia Tukova, Dale Ang,Erik Goormaghtigh, Jason Peterson, Victor Sharov, Nikola Chmel and Alison Rodger. Front. Chem. 9:784625 (2022) doi: 10.3389/fchem.2021.784625
    #A_IRfile = '../IR_ref/A50-AR-EG-IR_Sept2023.txt'
    A_IRfile = '../IRRefData/A50-AR-EG-IR_Sept2023.txt'
    F_IRfile = '../IRRefData/F50-AR-EG-IR_Sept2023.txt'
    #IR notes: 
    #Ref data are from 1600 to 1800 cm-1 in increasing order
    #Protein IR spectrum should also start from 1600 to 1800. We will interpolate the spectrum to steps of 1 cm-1
    IR_LowKInRefSet = 1600; IR_HighKInRefSet = 1800; IR_RefSetSteps = 1
    IR_RefSetNumDataPoints = 1 + ((IR_HighKInRefSet-IR_LowKInRefSet)/IR_RefSetSteps); print('IR_RefSetNumDataPoints: ', IR_RefSetNumDataPoints)
    
    LimWL = 1800 #is this right
    RefDataLowWL = 1800 #hack to make it fit 240-174 nm range thinking in the code
    #Now laod the reference data
    F1 =  np.loadtxt(F_IRfile, dtype='f', delimiter='\t')  ; print('F matrix shape: ', F1.shape)
    A1 = np.loadtxt(A_IRfile, dtype='f', delimiter='\t') ; print('A matrix shape: ', A1.shape)
    
    DataSet = 'IR'
    
#END: if (CD_or_IR == 'IR'):

if 'CD-IR' in CD_or_IR:
    A_CD_IRfile = '../'+'CD-IRRefDataAU' + '/' + 'AU-A28_CD-IR_Aug24.txt'
    if '2cm' in CD_or_IR:
        A_CD_IRfile = '../'+'CD-IRRefDataAU' + '/' + 'AU-A28_CD-IR2cm-1_Aug24.txt'
    F_CD_IRfile = '../'+'CD-IRRefDataAU' + '/' + 'AU-F28_CD-IR_Aug24.txt'
    LimWL = 175 #for CD data
    RefDataHighWL = 240
    RefDataLowWL = 175
    
    
    F1 = np.loadtxt(F_CD_IRfile, dtype='f', delimiter='\t')  ; print('F matrix shape: ', F1.shape)
    A2 = np.loadtxt(A_CD_IRfile, dtype='f', delimiter='\t') ; print('A matrix shape: ', A2.shape)
    
    #Scale IR part of A and thus extracted q
    IR_LowKInRefSet = 1600; IR_HighKInRefSet = 1800; IR_RefSetSteps = 1
    if '2cm' in CD_or_IR:
        IR_LowKInRefSet = 1600; IR_HighKInRefSet = 1720; IR_RefSetSteps = 2
    
    #The CD data are in pos 0 to 240-175 = 65 (66th element)
    CD_NumDataPointsInA2 = int(1+(RefDataHighWL-LimWL))
    A1_CD = A2[:CD_NumDataPointsInA2,:]
    A1_IR = A2[CD_NumDataPointsInA2:,:] * scaleIR
    A1 = np.concatenate([A1_CD,A1_IR]);
    
    if scaleIR == 0:
        #only use the CD part of the A
        A1 = A1_CD
    
    DataSet = 'CD-IR'
    if '2cm' in CD_or_IR:
        DataSet = 'CD-IR2cm'
        
#END: if 'CD-IR' in CD_or_IR:
    
if (mAbs_pH3Loop):
    #load the pH3 spectra
    A_mAbs_pH3file = 'A-mAbs_pH3.txt'
    A_mAbs_pH3 = np.loadtxt(A_mAbs_pH3file, dtype='f', delimiter='\t') ; print('A_mAbs_pH3 matrix shape: ', A_mAbs_pH3.shape)
    #print(A_mAbs_pH3)
    A=A1
    F=F1
    LoopFromSpectrum = 0 #first spectrum in A_mAbs_pH3
    for RefProteinNo in range(LoopFromSpectrum, A_mAbs_pH3.shape[1]):
        q=A_mAbs_pH3[:,RefProteinNo]
        MyProteinFile = "ProteinNo_{:d}.txt".format(RefProteinNo)
        
        Selcon3ResultsList = SelconsPy(A ,F, q, ShouldIPlot, ShouldIAlsoPlotSelcon2, LimWL, RefDataLowWL, MyProteinFile, MyProteinDir,AU_or_BBK, CD_or_IR)
        #print(Selcon3ResultsList)
        
        SP_or_SMP = ''
        fOut = open(MyProteinDir + MyProteinFile[0:-4]+'_SELCON3'+ SP_or_SMP + '' + DataSet + '_out.txt', 'w')
        for item in Selcon3ResultsList:
            fOut.write("%s\n" % item)
        fOut.close()
        
        if (RefProteinNo==0):
            with open(MyProteinDir + 'All_Results'+'_selcon3-'+ DataSet + '_out.txt', 'w') as f:
                item0=Selcon3ResultsList[-3]
                f.write("%s\n" % item0)
        #END: if (RefProteinNo==0):
        with open(MyProteinDir + 'All_Results'+'_selcon3-'+  DataSet + '_out.txt', 'a') as f:
            item1=Selcon3ResultsList[-2]
            f.write("%s\n" % item1)
            
        if (RefProteinNo==0):
            with open(MyProteinDir + 'All_Results'+'_selcon3-'+ DataSet + 'ProtUsed_out.txt', 'w') as f:
                #f.write("%s\n" % MyProteinFile[0:-4])
                item0='' #Selcon3ResultsList[-3]
                f.write("%s\n" % item0)
        #END: if (RefProteinNo==0):
        with open(MyProteinDir + 'All_Results'+'_selcon3-'+  DataSet + 'ProtUsed_out.txt', 'a') as f:
            f.write("%s\n" % MyProteinFile[0:-4])
            item1=Selcon3ResultsList[-1]
            f.write("%s\n" % item1)
    
    
    #sys.exit()
#End: if (mAbs_pH3Loop):

    
ShouldILOOV=True #False
if(ShouldILOOV):
    #loop over all proteins in the refrence data set (A1 / F1)
    for RefProteinNo in range(LoopFromSpectrum, A1.shape[1]): #71+2): #
        #Make new A and F matrix where REfProteinNo is left out.
        #q=np.zeros(A1.shape[0])
        MyProteinFile = "ProteinNo_{:d}.txt".format(RefProteinNo)
        
        A=np.delete(A1,RefProteinNo,1) #1=second axis or in this case the colomn
        F=np.delete(F1,RefProteinNo,1)
        q=A1[:,RefProteinNo]
    
        #Run the selcon3 function
        #def is              SelconsPy(A1,F,q1, ShouldIPlot, ShouldIAlsoPlotSelcon2, LimWL, RefDataLowWL, MyProteinFile, MyProteinDir,AU_or_BBK,CD_or_IR):
        Selcon3ResultsList = SelconsPy(A ,F, q, ShouldIPlot, ShouldIAlsoPlotSelcon2, LimWL, RefDataLowWL, MyProteinFile, MyProteinDir,AU_or_BBK, CD_or_IR)
        #IR_SpectraFromA_Dir = "IR_SpectraFromA/"; DataSet = 'IR'
        #IR_SpectraFromA_Dir = MyProteinDir; DataSet = 'IR'
        # if 'CD-IR' in CD_or_IR:
        #     #IR_SpectraFromA_Dir = "CD-IR_SpectraFromA/"; DataSet = 'CD-IR'
        #     IR_SpectraFromA_Dir = MyProteinDir; DataSet = 'CD-IR'
        #     if '2cm' in CD_or_IR:
        #         DataSet = 'CD-IR2cm'
    
        if (RefProteinNo==LoopFromSpectrum):
            with open(MyProteinDir + 'All_Results'+'_selcon3-'+ DataSet + '_out.txt', 'w') as f:
                item0=Selcon3ResultsList[-3]
                f.write("%s\n" % item0)
        #END: if (RefProteinNo==0):
        with open(MyProteinDir + 'All_Results'+'_selcon3-'+  DataSet + '_out.txt', 'a') as f:
            item1=Selcon3ResultsList[-2]
            f.write("%s\n" % item1)
        
    
        if (RefProteinNo==LoopFromSpectrum):
            with open(MyProteinDir + 'All_Results'+'_selcon3-'+ DataSet + 'ProtUsed_out.txt', 'w') as f:
                #item0=Selcon3ResultsList[-2]
                #f.write("%s\n" % item0)
                f.write("%s" % '')
        #END: if (RefProteinNo==0):
        with open(MyProteinDir + 'All_Results'+'_selcon3-'+  DataSet + 'ProtUsed_out.txt', 'a') as f:
            #f.write("%s\n" % MyProteinFile[0:-4])
            item1=Selcon3ResultsList[-1]
            f.write("%s\n" % item1)
       
    #END: for RefProteinNo in range(A1.shape[1]):